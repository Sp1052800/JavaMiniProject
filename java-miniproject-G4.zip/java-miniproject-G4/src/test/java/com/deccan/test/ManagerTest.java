package com.deccan.test;

import java.time.LocalTime;
import java.util.List;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.deccan.dto.AllPlansInfo;
import com.deccan.dto.BatchList;
import com.deccan.model.Batch;
import com.deccan.model.Plan;
import com.deccan.services.BatchService;
import com.deccan.services.IBatchService;
import com.deccan.services.IPlanService;
import com.deccan.services.PlanService;

@Ignore
public class ManagerTest {

	private static IPlanService planService=null;
	private static IBatchService batchService=null;
	@BeforeAll
	public static void setup() {
		 planService = new PlanService();
		 batchService=new BatchService();
	}
	
	@Test 
	public void testAddPlan() throws Exception {
		Plan plan =new Plan();
		 plan.setPlanName("Football");
		 plan.setFees(2500.00);
		 plan.setDuration("3");
		 plan.setSportsId("DS74586");
		
		planService.addPlan(plan);
		
		Assert.assertEquals("DS74586",plan.getSportsId());
	}
	
	@Test 
	public void testGetAllPlans() throws Exception {
		List<AllPlansInfo> result = planService.displayPlans();
		
		Assert.assertNotNull(result);
	}
	
	@Test 
	public void testGetPlanByPlanId() throws Exception {
		Plan result = planService.getPlan("DP97079");
		
		Assert.assertNotNull(result);
	}
	
	@Test 
	public void testDeletePlan() throws Exception {
		int result = planService.removePlan("DP97079");
		
		Assert.assertEquals(1,result);
	}
	
	@Test
	public void testAddBatch() throws Exception {
		Batch batch = new Batch();
		batch.setBatchDuration("3");
		batch.setSize(25);
		batch.setStartTime(LocalTime.parse("14:00"));
		batch.setSportsId("DS74586");
		Batch result =batchService.addBatch(batch);
		
		Assert.assertEquals("DS74586",result.getSportsId());
		
	}
	
	@Test 
	public void testGetBatchByBatchId() throws Exception {
		Batch batch = batchService.getBatchById("DB24238");
		
		Assert.assertNotNull(batch);
	}
	
	@Test 
	public void testGetAllBatches() throws Exception {
		List<BatchList> result = batchService.displayBatches();
		
		Assert.assertNotNull(result);
	}
	
	@Test
	public void testUpdateBatch() throws Exception {
		Batch batch = batchService.getBatchById("DB24238");
		batch.setBatchDuration("3");
		batch.setSize(25);
		batch.setStartTime(LocalTime.parse("15:00"));
		batch.setSportsId("DS64535");
		Batch result =batchService.updateBatch(batch);
		
		Assert.assertEquals("2",result.getBatchDuration());
	}
	
	@Test 
	public void testDeleteBatch() throws Exception {
		int result = batchService.removeBatch("DB24238");
		
		Assert.assertEquals(1,result);
	}
}