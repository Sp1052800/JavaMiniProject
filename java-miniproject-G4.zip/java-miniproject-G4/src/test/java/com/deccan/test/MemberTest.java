package com.deccan.test;

import java.util.List;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.deccan.dto.AllPlansInfo;
import com.deccan.model.Enrollment;
import com.deccan.model.User;
import com.deccan.services.IUserService;
import com.deccan.services.UserService;

public class MemberTest {

private static IUserService userService =null;
	
	@BeforeAll
	public static void setup() {
		 userService = new UserService();
	}
	
	@Test
	public void testRegister() throws Exception {
		User user=new User();
		user.setAddress("Pune");
		user.setContact("9945968596");
		user.setPassword("123456");
		user.setRole("member");
		user.setUserEmail("johnny@hotmail.com");
		user.setUserName("Johnny Deep");
		User result =userService.addManager(user);
		Assert.assertEquals("johnny@hotmail.com",result.getUserEmail());
	}
	
	@Test
	public void testUpdateUser() throws Exception {
		User user = userService.getUser("DU20380");
		
		user.setAddress("Indore");
		user.setContact("9996587559");
		
		
		User result =userService.updateManager(user);
		Assert.assertEquals("9996587559",result.getContact());
	}
	@Test
	public void testGetAllPlans() throws Exception{
		List<AllPlansInfo> result = userService.displayPlans();
		
		Assert.assertNotNull(result);
	}
	
	
}