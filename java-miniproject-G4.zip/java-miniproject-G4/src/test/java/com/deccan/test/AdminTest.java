package com.deccan.test;

import java.util.List;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.deccan.model.User;
import com.deccan.services.IUserService;
import com.deccan.services.UserService;

public class AdminTest {

	private static IUserService userService =null;
	
	@BeforeAll
	public static void setup() {
		 userService = new UserService();
	}
	
	@Test
	public void testAddManager() throws Exception {
		User user=new User();
		user.setAddress("Indore");
		user.setContact("9945968596");
		user.setPassword("123456");
		user.setRole("manager");
		user.setUserEmail("jack@hotmail.com");
		user.setUserName("Jack Sparrow");
		User result =userService.addManager(user);
		Assert.assertEquals("jack@hotmail.com",result.getUserEmail());
	}
	
	
	@Test
	public void testUpdateManager() throws Exception {
		User user = userService.getUser("DU21091");
		
		user.setAddress("Indore");
		user.setContact("9996587559");
		
		
		User result =userService.updateManager(user);
		Assert.assertEquals("9996587559",result.getContact());
	}
	
	@Test
	public void testManageList() throws Exception {
		List<User> result = userService.displayManagers();
		Assert.assertNotNull(result);
	}
	
	@Test
	public void deleteManager() throws Exception {
		int result  = userService.removeManager("DU19973");
		
		Assert.assertEquals(1, result);
	}
}