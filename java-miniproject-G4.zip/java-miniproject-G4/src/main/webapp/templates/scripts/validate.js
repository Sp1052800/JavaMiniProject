$(document).ready(function() {
	$('#btnRegister').click(function() {
		$('.error').empty()
	
		if ($('#userName').val() === '' || $('#userName').val().length < 4) {
			$('.error').append('Invalid username')
			return false
		}
		
		
		
		else if ($('#password').val() === '' || $('#password').val().length < 6) {
			$('.error').append('Please enter valid password, min 6 digit.')
			return false
		}
		

		let pattern = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/
		let email = $('#userEmail').val();
		if (!pattern.test(email)) {
		
			$('.error').append("Please enter valid email address.")
			return false
		}
		
		let phonePattern=/(6|7|8|9)\d{9}/
		let contact= $('#contact').val();
		if(!phonePattern.test(contact)){
			$('.error').append("Please enter 10 digits of a contact number which should start with only 6,7,8,9.")
			return false
		}
    	else if ($('#contact').val().length!=10 ){
        	$('.error').append("Please enter valid contact number.")
		    return false
		}
		$('#formSub').submit()
		return true
	 })
})