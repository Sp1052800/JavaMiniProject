package com.deccan.dto;

/**
 * @author Administrator
 *
 */
public class PlanFrom {
	private String planId;
	public String getPlanId() {
		return planId;
	}

	public void setPlanId(String planId) {
		this.planId = planId;
	}

	private String planName;
	private String sportName;
	private double fees;
	private String duration;
	private String sportsId;
	
	
	public PlanFrom(String planId, String planName, String sportName, double fees, String duration,String sportsId) {
		super();
		this.planId=planId;
		this.planName = planName;
		this.sportName = sportName;
		this.fees = fees;
		this.duration = duration;
		this.sportsId=sportsId;
	}
	
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	
	
	public String getSportid() {
		return sportsId;
	}
	public void setSportid(String sportid) {
		this.sportsId = sportid;
	}
	public String getSportName() {
		return sportName;
	}
	public void setSportName(String sportName) {
		this.sportName = sportName;
	}
	public double getFees() {
		return fees;
	}
	public void setFees(double fees) {
		this.fees = fees;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}

	@Override
	public String toString() {
		return "PlanFrom [planId=" + planId + ", planName=" + planName + ", sportName=" + sportName + ", fees=" + fees
				+ ", duration=" + duration + ", sportsId=" + sportsId + "]";
	}
	
	
}
