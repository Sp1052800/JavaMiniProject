package com.deccan.dto;

import java.time.LocalDate;
import java.time.LocalTime;

public class EnrollmentInfo {

	private String enrollmentId;
	private String userName;
	private String planName;
	private double fees;
	private LocalDate startDate;
	private int batchSize;
	private LocalTime batchStartTime;
	private String status;
	
	
	public EnrollmentInfo() {
	
	}
	
	public EnrollmentInfo(String enrollmentId, String userName, String planName, double fees, LocalDate startDate,
			int batchSize, LocalTime batchStartTime, String status) {
		super();
		this.enrollmentId = enrollmentId;
		this.userName = userName;
		this.planName = planName;
		this.fees = fees;
		this.startDate = startDate;
		this.batchSize = batchSize;
		this.batchStartTime = batchStartTime;
		this.status = status;
	}

	public String getEnrollmentId() {
		return enrollmentId;
	}
	public void setEnrollmentId(String enrollmentId) {
		this.enrollmentId = enrollmentId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public LocalDate getStartDate() {
		return startDate;
	}
	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}
	public int getBatchSize() {
		return batchSize;
	}
	public void setBatchSize(int batchSize) {
		this.batchSize = batchSize;
	}
	public LocalTime getBatchStartTime() {
		return batchStartTime;
	}
	public void setBatchStartTime(LocalTime batchStartTime) {
		this.batchStartTime = batchStartTime;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public double getFees() {
		return fees;
	}

	public void setFees(double fees) {
		this.fees = fees;
	}

	@Override
	public String toString() {
		return "EnrollmentInfo [enrollmentId=" + enrollmentId + ", userName=" + userName + ", planName=" + planName
				+ ", fees=" + fees + ", startDate=" + startDate + ", batchSize=" + batchSize + ", batchStartTime="
				+ batchStartTime + ", status=" + status + "]";
	}

}
