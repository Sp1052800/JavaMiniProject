package com.deccan.dao;

import java.util.List;

import com.deccan.dto.EnrollmentInfo;
import com.deccan.exception.CustomException;

public interface IEnrollmentDao {

	public List<EnrollmentInfo> displayEnrollments() throws CustomException, Exception;
	public void approveMember(String enrollmentId) throws CustomException, Exception;
	public void rejectMember(String enrollmentId) throws CustomException, Exception;
	public List<EnrollmentInfo> memberEnrollment(String userId) throws CustomException, Exception;
	public EnrollmentInfo viewReceipt(String enrollmentId) throws CustomException, Exception;
}
