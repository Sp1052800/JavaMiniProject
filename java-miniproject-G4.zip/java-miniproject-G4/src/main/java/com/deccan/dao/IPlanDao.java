package com.deccan.dao;

import java.util.List;

import com.deccan.dto.AllPlansInfo;
import com.deccan.exception.CustomException;
import com.deccan.model.Plan;


public interface IPlanDao {
	public List<AllPlansInfo> displayPlans() throws CustomException, Exception ;
	public int addPlan(Plan plan) throws CustomException, Exception;
	public Plan update(Plan plan) throws CustomException, Exception;
	public int removePlan(String planId) throws CustomException, Exception;
	public Plan getPlan(String planId) throws CustomException, Exception;
	
}
