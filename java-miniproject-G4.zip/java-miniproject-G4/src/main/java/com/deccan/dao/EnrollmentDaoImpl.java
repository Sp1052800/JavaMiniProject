package com.deccan.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import com.deccan.dbutils.DbUtil;
import com.deccan.dto.EnrollmentInfo;
import com.deccan.exception.CustomException;
import com.deccan.model.Enrollment;

public class EnrollmentDaoImpl implements IEnrollmentDao {
	
	@Override
	public List<EnrollmentInfo> displayEnrollments() throws CustomException, Exception {

		String sql = "SELECT enrollment.enrollmentId,users.userName," + "plans.planName,batch.startTime,batch.size,"
				+ "enrollment.startDate,enrollment.status "
				+ "FROM enrollment INNER JOIN plans ON plans.planId=enrollment.planId "
				+ "INNER JOIN batch ON batch.batchId = enrollment.batchId "
				+ "INNER JOIN users ON users.userId = enrollment.memberId " + "ORDER BY status DESC";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);

		ResultSet rs = ps.executeQuery();

		List<EnrollmentInfo> enrollments = new ArrayList<EnrollmentInfo>();
		while (rs.next()) {
			
			EnrollmentInfo enrollMember = new EnrollmentInfo();

			enrollMember.setEnrollmentId(rs.getString(1));
			enrollMember.setUserName(rs.getString(2));
			enrollMember.setPlanName(rs.getString(3));
			enrollMember.setStartDate(LocalDate.parse(rs.getString(6)));
			enrollMember.setBatchStartTime(LocalTime.parse(rs.getString(4)));
			enrollMember.setBatchSize(rs.getInt(5));
			enrollMember.setStatus(rs.getString(7));

			enrollments.add(enrollMember);
		}if(enrollments!=null) {
			return enrollments;

		}else {
			throw new CustomException("Enrollment entries not found.");
		}
	}

	@Override
	public void approveMember(String enrollmentId) throws CustomException, Exception {
		String sql="update enrollment set status=? where enrollmentId=?";
		Connection connection = DbUtil.getConnection();
		connection.setAutoCommit(false);
		PreparedStatement ps = connection.prepareStatement(sql);
		ps.setString(1, "APPROVED");
		ps.setString(2,enrollmentId);
		if(ps.executeUpdate() == 1) {
			connection.commit();			
			ps.close(); 
			connection.close();  
		}
		else{ 
			connection.rollback();
			ps.close(); 
			connection.close(); 
			throw new CustomException("Enrollment approval failed for enrollmentId : "+enrollmentId);
		}
	}

	@Override
	public void rejectMember(String enrollmentId) throws CustomException, Exception {
		String sql="update enrollment set status=? where enrollmentId=?";
		Connection connection = DbUtil.getConnection();
		connection.setAutoCommit(false);
		PreparedStatement ps = connection.prepareStatement(sql);
		ps.setString(1, "NOT APPROVED");
		ps.setString(2,enrollmentId);
		if(ps.executeUpdate() == 1) {
			connection.commit();			
			ps.close(); 
			connection.close();  
		}
		else{ 
			connection.rollback();
			ps.close(); 
			connection.close(); 
			throw new CustomException("Enrollment rejection failed for enrollmentId : "+enrollmentId);
		}
		
	}
	
	@Override
	public List<EnrollmentInfo> memberEnrollment(String userId) throws CustomException, Exception {
		String sql = "SELECT " + "plans.planName,batch.startTime,"
				+ "enrollment.startDate,enrollment.status,"+"enrollment.enrollmentId "
				+ "FROM enrollment INNER JOIN plans ON plans.planId=enrollment.planId "
				+ "INNER JOIN batch ON batch.batchId = enrollment.batchId "
			     +"AND enrollment.memberId = ?"+ " ORDER BY status DESC";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, userId);
		ResultSet rs = ps.executeQuery();

		List<EnrollmentInfo> enrollments = new ArrayList<EnrollmentInfo>();
		while (rs.next()) {

			int length = rs.getString(3).length();
			System.out.println(length);

			EnrollmentInfo enrollMember = new EnrollmentInfo();

			enrollMember.setPlanName(rs.getString("planName"));
			enrollMember.setStartDate(LocalDate.parse(rs.getString("startDate")));
			enrollMember.setBatchStartTime(LocalTime.parse(rs.getString("startTime")));
			enrollMember.setStatus(rs.getString("status"));
			enrollMember.setEnrollmentId(rs.getString("enrollmentId"));
			enrollments.add(enrollMember);
			System.out.println(enrollments.toString());
		}
		if(enrollments!=null) {
			return enrollments;

		}else {
			throw new CustomException("Enrollment entries for user not found.");
		}

     }

	@Override
	public EnrollmentInfo viewReceipt(String enrollmentId) throws CustomException, Exception {
		String sql = "SELECT " +"users.userName,"+ "plans.planName,enrollment.startDate,plans.fees "
				
				+ "FROM enrollment INNER JOIN plans ON plans.planId=enrollment.planId "
				+ "INNER JOIN users ON users.userId = enrollment.memberId "
			     +"AND enrollment.enrollmentId = ?";
		
		
	/*	select users.userName,plans.planName,enrollment.startDate,plans.fees FROM enrollment INNER JOIN plans ON plans.planId=enrollment.planId 
				 INNER JOIN users ON users.userId = enrollment.memberId 
			     AND enrollment.enrollmentId = "DE97794";*/
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, enrollmentId);
		ResultSet rs = ps.executeQuery();
		EnrollmentInfo enrollmentInfo = new EnrollmentInfo();
		if(rs.next()) {
			enrollmentInfo.setUserName(rs.getString("userName"));
			enrollmentInfo.setPlanName(rs.getString("planName"));
			enrollmentInfo.setStartDate(LocalDate.parse(rs.getString("startDate")));
			enrollmentInfo.setFees(rs.getDouble("fees"));
		}
		if(enrollmentInfo!=null) {
			System.out.println(enrollmentInfo);
			return enrollmentInfo;

		}else {
			throw new CustomException("Enrollment entries for user not found.");
		}
	
	}

}
