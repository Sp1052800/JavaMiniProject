package com.deccan.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import com.deccan.dbutils.DbUtil;
import com.deccan.dto.AllPlansInfo;
import com.deccan.exception.CustomException;
import com.deccan.model.Batch;
import com.deccan.model.Enrollment;
import com.deccan.model.Plan;
import com.deccan.model.User;

public class UserDaoImpl implements IUserDao {

	
	@Override
	public User register(User user) throws CustomException, Exception {
		String sql = "insert into users values(?,?,?,?,?,?,?)";
		Connection con = DbUtil.getConnection();
		con.setAutoCommit(false);
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, user.getUserId());
		ps.setString(2, user.getUserName());
		ps.setString(3, user.getUserEmail());
		ps.setString(4, user.getPassword());
		ps.setString(5, user.getRole());
		ps.setString(6, user.getContact());
		ps.setString(7, user.getAddress());

		if (ps.executeUpdate() == 1) {
			con.commit(); // user will be committed
			ps.close();
			con.close();
			return user;
		} else {
			con.rollback();
			ps.close();
			con.close();
			throw new CustomException("Error while registering user");
		}

	}

	@Override
	public User updateUser(User user) throws CustomException, Exception {
		String sql = "update users set userName=?, userEmail=?, password = ? , role = ?, contact=?,address=? where userId = ?";
		Connection connection = DbUtil.getConnection();
		connection.setAutoCommit(false);
		PreparedStatement ps = connection.prepareStatement(sql);		
		ps.setString(1, user.getUserName());
		ps.setString(2, user.getUserEmail());
		ps.setString(3, user.getPassword());
		ps.setString(4, user.getRole());
		ps.setString(5, user.getContact());
		ps.setString(6, user.getAddress());
		ps.setString(7, user.getUserId());

		if(ps.executeUpdate() == 1) {
			connection.commit();			//user  will be committed
			ps.close(); 
			connection.close();  
			return user;
		}
		else{ 
			connection.rollback();
			ps.close(); 
			connection.close(); 
			throw new CustomException("Error while updating user");
		}
	}

	@Override

	public List<User> displayManagers() throws CustomException, Exception {
		String sql = "select * from users where role = ?";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ps.setString(1, "manager");
		ResultSet rs = ps.executeQuery();

		List<User> users = new ArrayList<User>();
		while (rs.next()) {
			users.add(new User(rs.getString("userId"), rs.getString("userName"), rs.getString("userEmail"),
					rs.getString("password"), rs.getString("role"), rs.getString("contact"), rs.getString("address")));
		}
		if(users!=null) {
			return users;

		}else {
			throw new CustomException("Manager entries not found.");
		}
	}

	@Override
	public int removeManager(String userId) throws CustomException, Exception {

		String sql = "delete from users where userId = ?";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ps.setString(1, userId);
		int result =ps.executeUpdate();
		if(result==1)
			return result;
		else {
			throw new CustomException("Error while deleting manager.");
		}

	}

	@Override
	public User getUser(String userId) throws CustomException, Exception {
		String sql = "select * from users where userId = ?";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ps.setString(1, userId);
		ResultSet rs = ps.executeQuery();
		User  user = null;
		if(rs.next()) {
			user = new User(rs.getString(1),rs.getString(2), rs.getString(3), rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7));
		}else {
			throw new CustomException("No user found for userid : "+userId);
		}
		return user;
	}

	@Override
	public User updateManager(User user) throws CustomException, Exception {
		String sql = "update users set userName=?, userEmail=?, password=?, role=?, contact=?, address=? where userId=?";
		Connection con = DbUtil.getConnection();
		con.setAutoCommit(false);
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, user.getUserName());
		ps.setString(2, user.getUserEmail());
		ps.setString(3, user.getPassword());
		ps.setString(4, user.getRole());
		ps.setString(5, user.getContact());
		ps.setString(6, user.getAddress());
		ps.setString(7, user.getUserId());
		if (ps.executeUpdate() == 1) {
			con.commit(); // user will be committed
			ps.close();
			con.close();
			return user;
		} else {
			con.rollback();
			ps.close();
			con.close();
			throw new CustomException("Error while updating manager with userId : "+user.getUserId());
		}

	}

	@Override
	public List<AllPlansInfo> displayPlanlist() throws CustomException, Exception {

		String sql="select p.planId,s.sportsId,p.planName,p.fees,p.duration,s.sportName from plans p inner join sports s on s.sportsId=p.sportsId";
		Connection con= DbUtil.getConnection();
		PreparedStatement ps= con.prepareStatement(sql);
		List<AllPlansInfo>planList = new ArrayList<AllPlansInfo>();
		ResultSet rs= ps.executeQuery();
		while(rs.next()) {
			planList.add(new AllPlansInfo(rs.getString("planId"), rs.getString("sportsId"), rs.getString("planName"), rs.getDouble("fees"), rs.getInt("duration"), rs.getString("sportName")));
		}
		if(planList!=null) {
			return planList;

		}else {
			throw new CustomException("Plan entries not found.");

		}
	}

	@Override
	public User getUserByEmail(String userEmail) throws CustomException, Exception {
		String sql = "select * from users where userEmail = ?";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ps.setString(1, userEmail);
		ResultSet rs = ps.executeQuery();
		User  user = null;
		if(rs.next()) {
			user = new User(rs.getString(1),rs.getString(2), rs.getString(3), rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7));
		}else {
			throw new CustomException("Error in getting user by email id : "+userEmail);
		}
		return user;
	}
	
	public User addManager(User user) throws CustomException, Exception {
		System.out.println("In UserDao impl " + user);
		String sql = "insert into users values(?,?,?,?,?,?,?)";
		Connection con = DbUtil.getConnection();
		con.setAutoCommit(false);
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, user.getUserId());
		ps.setString(2, user.getUserName());
		ps.setString(3, user.getUserEmail());
		ps.setString(4, user.getPassword());
		ps.setString(5, user.getRole());
		ps.setString(6, user.getContact());
		ps.setString(7, user.getAddress());

		if (ps.executeUpdate() == 1) {
			con.commit(); // user will be committed
			ps.close();
			con.close();
			return user;
		} else {
			con.rollback();
			ps.close();
			con.close();
			throw new CustomException("Error while adding manager");
		}
	}

	@Override
	public Enrollment enrollUser(Enrollment enroll) throws CustomException, Exception {
		String sql = "INSERT into enrollment values(?,?,?,?,?,?)";
		Connection con = DbUtil.getConnection();
		con.setAutoCommit(false);
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, enroll.getEnrollmentId());

		ps.setString(2, enroll.getStatus());
		Date date=Date.valueOf(enroll.getStartDate());
		ps.setDate(3, date);
		ps.setString(4, enroll.getUser().getUserId());
		ps.setString(5, enroll.getBatch().getBatchId());
		ps.setString(6, enroll.getPlan().getPlanId());
		if (ps.executeUpdate() == 1) {
			con.commit(); // user will be committed
			ps.close();
			con.close();
			return enroll;
		} else {
			con.rollback();
			ps.close();
			con.close();
			throw new CustomException("Error while enrolling into plan");
		}

	}

	public Plan getPlanByPlanId(String planId) throws CustomException, Exception {
		System.out.println(planId);
		String sql = "select * from Plans where planId= ?";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ps.setString(1,planId );
		ResultSet rs = ps.executeQuery();
		Plan  plan = null;
		if(rs.next()) {
			plan = new Plan(rs.getString(1),rs.getString(2), rs.getDouble(4), rs.getString(3));
		}else {
			throw new CustomException("Error in getting plan by plan id : "+planId);
		}
		return plan;

	}

	@Override
	public List<Batch> getAllBatches() throws CustomException, Exception {
		String sql="select batchId,startTime from batch";
		Connection con= DbUtil.getConnection();
		PreparedStatement ps= con.prepareStatement(sql);
		List<Batch>batches = new ArrayList<Batch>();
		ResultSet rs= ps.executeQuery();
		while(rs.next()) {
			batches.add(new Batch(rs.getString("batchId"),rs.getTime("startTime").toLocalTime()));
		}if(batches!=null) {
			return batches;

		}
		else {
			throw new CustomException("Batch entries not found.");
		}
	}

	@Override
	public Batch getBatchIdByBatchTime(LocalTime batchTime) throws CustomException, Exception {
		System.out.println(batchTime);
		String sql = "select batchId,startTime from batch where startTime= ? ";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ps.setObject(1, batchTime);
		ResultSet rs = ps.executeQuery();
		Batch  batch = null;
		if(rs.next()) {
			System.out.println( "hdgj"+rs.getString(1));
			System.out.println(rs.getTime(2).toLocalTime());
			batch = new Batch(rs.getString(1),rs.getTime(2).toLocalTime());
		}else {
			throw new CustomException("Batch not found for given batch time : "+batchTime);
		}
		return batch;

	}
}
