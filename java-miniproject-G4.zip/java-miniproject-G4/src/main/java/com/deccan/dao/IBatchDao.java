package com.deccan.dao;

import java.util.List;

import com.deccan.dto.BatchList;
import com.deccan.exception.CustomException;
import com.deccan.model.Batch;

public interface IBatchDao {
	public List<BatchList> displayBatches() throws CustomException, Exception;
	public Batch addBatch(Batch batch) throws CustomException, Exception;
	public Batch updateBatch(Batch batch) throws CustomException, Exception;
	public int removeBatch(String batchId) throws CustomException, Exception;
	public void updateBatchSize(String enrollmentId, int size) throws CustomException, Exception;
	public Batch getBatchById(String batchId) throws CustomException, Exception;
}
