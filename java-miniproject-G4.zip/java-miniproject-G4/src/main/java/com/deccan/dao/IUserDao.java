package com.deccan.dao;

import java.time.LocalTime;
import java.util.List;

import com.deccan.dto.AllPlansInfo;
import com.deccan.exception.CustomException;
import com.deccan.model.Batch;
import com.deccan.model.Enrollment;
import com.deccan.model.Plan;
import com.deccan.model.User;


public interface IUserDao {
	public User register(User user) throws CustomException,  Exception;

	
	public User updateUser(User user) throws CustomException,  Exception;
	public User getUser(String userId) throws CustomException,  Exception;
	public User getUserByEmail(String userEmail) throws CustomException,  Exception;
	public User updateManager(User user) throws CustomException, Exception;
	public List<User> displayManagers() throws CustomException, Exception;
	public int removeManager(String userId) throws CustomException, Exception;
	public List<AllPlansInfo> displayPlanlist()throws CustomException,  Exception;

	public User addManager(User user) throws CustomException, Exception;

	
	public Plan getPlanByPlanId(String planId)throws CustomException, Exception;
	public List<Batch> getAllBatches() throws CustomException, Exception;
	public Batch getBatchIdByBatchTime(LocalTime startTime)throws CustomException, Exception;


	Enrollment enrollUser(Enrollment enroll) throws CustomException, Exception;

}
