package com.deccan.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.deccan.dbutils.DbUtil;
import com.deccan.dto.AllPlansInfo;
import com.deccan.dto.PlanFrom;
import com.deccan.exception.CustomException;
import com.deccan.model.Plan;

public class PlanDaoImpl implements IPlanDao {
	private Connection connection =null;
	private PreparedStatement ps=null;
	@Override
	public List<AllPlansInfo> displayPlans() throws CustomException, Exception {
		String sql = "SELECT plans.planId, plans.planName, sports.sportName, plans.fees, plans.duration, plans.sportsId "
				+"FROM plans "
				+"INNER JOIN sports ON plans.sportsId=sports.sportsId";

		connection = DbUtil.getConnection();
		ps = connection.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();

		List<AllPlansInfo> plan = new ArrayList<AllPlansInfo>();
		if(rs!=null) {
			while(rs.next()) {

				plan.add(new AllPlansInfo(rs.getString("planId"), rs.getString("sportsId"), rs.getString("planName"),
						rs.getDouble("fees"), rs.getInt("duration"), rs.getString("sportName")));
			}
		}else {
			throw new CustomException("Plan entries not found.");
		}
		return plan;
	}

	@Override
	public int addPlan(Plan plan) throws CustomException, Exception {
		String sql = "insert into plans values(?, ?, ?,?,?)";
		connection = DbUtil.getConnection();
		ps = connection.prepareStatement(sql);

		ps.setString(1, plan.getPlanId());
		ps.setString(2, plan.getPlanName());
		ps.setString(3, plan.getSportsId());
		ps.setDouble(4, plan.getFees());
		ps.setString(5, plan.getDuration());
		int result=ps.executeUpdate();
		if(result!=0)
		return result;
		else {
			throw new CustomException("Error while adding plan.");
		}
	}

	@Override
	public Plan update(Plan plan) throws CustomException, Exception {
		String sql = "update plans set planName=?, sportsId=?, fees=?, duration=? where planId=?";
		connection = DbUtil.getConnection();
		connection.setAutoCommit(false);
		ps = connection.prepareStatement(sql);

		ps.setString(1, plan.getPlanName());
		ps.setString(2, plan.getSportsId());
		ps.setDouble(3, plan.getFees());
		ps.setString(4, plan.getDuration());
		ps.setString(5, plan.getPlanId());

		if (ps.executeUpdate() == 1) {
			connection.commit(); // user will be committed
			ps.close();
			connection.close();
			return plan;
		} else {
			connection.rollback();
			ps.close();
			connection.close();
			throw new CustomException("Error while updating plan with planId : "+plan.getPlanId());
		}


	}

	@Override
	public int removePlan(String planId) throws CustomException, Exception {
		String sql = "delete from plans where planId = ?";
		connection = DbUtil.getConnection();
		ps = connection.prepareStatement(sql);		
		ps.setString(1, planId);			

		int result=ps.executeUpdate();
		if(result!=0)
		return result;
		else {
			throw new CustomException("Error while removing plan with planId : "+planId);
		}

	}

	@Override
	public Plan getPlan(String planId) throws CustomException, Exception {
		String sql = "select * from plans where planId = ?";
		connection = DbUtil.getConnection();
		ps = connection.prepareStatement(sql);

		ps.setString(1, planId);
		ResultSet rs = ps.executeQuery();
		Plan  plan = null;
		if(rs.next()) {

			plan = new Plan(rs.getString(1), rs.getString(2), rs.getDouble(4), rs.getString(5), rs.getString(3));
		}else {
			throw new CustomException("No plan found for planId : "+planId);
		}
		return plan;
	}

}
