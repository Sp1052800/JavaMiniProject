package com.deccan.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.deccan.dbutils.DbUtil;
import com.deccan.dto.BatchList;
import com.deccan.exception.CustomException;
import com.deccan.model.Batch;

public class BatchDaoImpl implements IBatchDao {

	@Override
	public List<BatchList> displayBatches() throws CustomException, Exception {
		String sql = "SELECT batch.batchId," + "batch.startTime,  " + "batch.batchDuration, " + "batch.size,"
				+ "sports.sportName " + "FROM batch " + "INNER JOIN sports ON " + "batch.sportsId=sports.sportsId;";

		Connection connection = DbUtil.getConnection();

		PreparedStatement preparedStatement = connection.prepareStatement(sql);
		ResultSet resultSet = preparedStatement.executeQuery();

		List<BatchList> listOfBatches = new ArrayList<BatchList>();

		while (resultSet.next()) {
			listOfBatches.add(new BatchList(resultSet.getString(1), resultSet.getTime(2).toLocalTime(), resultSet.getString(3),
					resultSet.getInt(4), resultSet.getString(5)));
		}if(listOfBatches!=null) {
			return listOfBatches;

		}else {
			throw new CustomException("Batch entries not found.");
		}
	}

	@Override
	public Batch addBatch(Batch batch) throws CustomException, Exception {

		String sql = "insert into batch values(?,?,?,?,?)";

		Connection connection = DbUtil.getConnection();
		PreparedStatement preparedStatement = connection.prepareStatement(sql);

		preparedStatement.setString(1, batch.getBatchId());
		preparedStatement.setObject(2, batch.getStartTime());
		preparedStatement.setString(3, batch.getBatchDuration());
		preparedStatement.setInt(4, batch.getSize());
		preparedStatement.setString(5, batch.getSportsId());
		
		if(preparedStatement.executeUpdate()!=0)
		return batch;
		else {
			throw new CustomException("Error while adding batch.");
		}
		
	}

	@Override
	public Batch updateBatch(Batch batch) throws CustomException, Exception {
		String sql = "UPDATE batch"
				+ " SET startTime = ?, batchDuration = ?,size=?, sportsId=?"
				+ " WHERE batchId =?";
			Connection connection = DbUtil.getConnection();
			connection.setAutoCommit(false);
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setObject(1, batch.getStartTime());
			preparedStatement.setString(2, batch.getBatchDuration());
			preparedStatement.setInt(3, batch.getSize());
			preparedStatement.setString(4, batch.getSportsId());
			preparedStatement.setString(5, batch.getBatchId());
			if(preparedStatement.executeUpdate() == 1) {
				connection.commit();			
				preparedStatement.close(); 
				connection.close();  
				return batch;
			}
			else{ 
				connection.rollback();
				preparedStatement.close(); 
				connection.close(); 
				throw new CustomException("Error while updating batch.");
				
			}
		
	}

	@Override
	public int removeBatch(String batchId) throws CustomException, Exception {
		String sql = "delete from batch where batchId=?";
		Connection connection = DbUtil.getConnection();
		PreparedStatement preparedStatement = connection.prepareStatement(sql);
		preparedStatement.setString(1, batchId);
		int resultSet = preparedStatement.executeUpdate();
		if(resultSet ==0) {
			throw new CustomException("Error while removing batch with batchId : "+batchId);
		}
		return resultSet;
	}

	@Override
	public void updateBatchSize(String enrollmentId, int size) throws CustomException, Exception {
		String sql = "select batchId from enrollment where enrollmentId=?";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ps.setString(1, enrollmentId);
		ResultSet rs = ps.executeQuery();
		String batchId = null;
		if (rs.next()) {
			batchId = rs.getString(1);
		}

		String sql1 = "update batch set size=? where batchId=?";
		Connection con = DbUtil.getConnection();
		con.setAutoCommit(false);
		PreparedStatement ps1 = con.prepareStatement(sql1);
		ps1.setInt(1, size);
		ps1.setString(2, batchId);
		if (ps1.executeUpdate() == 1) {
			con.commit(); // user will be committed
			ps1.close();
			con.close();
		} else {
			con.rollback();
			ps1.close();
			con.close();
			throw new CustomException("Error while updating batch size");
		}
	}
	@Override
	public Batch getBatchById(String batchId) throws CustomException, Exception {
		String sql="select * from batch where batchId=?";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ps.setString(1, batchId);
		ResultSet resultSet = ps.executeQuery();
		Batch batch=null;
		if(resultSet.next()) {
			batch = new Batch(resultSet.getString(1),resultSet.getTime(2).toLocalTime(),resultSet.getString(3),resultSet.getInt(4),resultSet.getString(5));
		}else {
			throw new CustomException("Batch not found for batchId : "+batchId);
		}

		return batch ;
	}

}
