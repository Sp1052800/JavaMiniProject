package com.deccan.services;

import java.util.List;

import com.deccan.dao.BatchDaoImpl;
import com.deccan.dao.EnrollmentDaoImpl;
import com.deccan.dao.IBatchDao;
import com.deccan.dao.IEnrollmentDao;
import com.deccan.dao.IUserDao;
import com.deccan.dao.UserDaoImpl;
import com.deccan.dto.EnrollmentInfo;
import com.deccan.exception.CustomException;
import com.deccan.model.Enrollment;

public class EnrollmentService implements IEnrollmentService{
	
	IEnrollmentDao enrollmentDao = new EnrollmentDaoImpl();private IUserDao userDao=new UserDaoImpl();
	IBatchDao batchDao = new BatchDaoImpl();
	private String generateEnrollmentId() {
		return "DE"+Math.round(Math.random()*99999);
	}
	@Override
	public List<EnrollmentInfo> displayEnrollments() throws Exception {
		
		return enrollmentDao.displayEnrollments();
	}

	@Override
	public void rejectMember(String enrollmentId) throws Exception {
		enrollmentDao.rejectMember(enrollmentId);
		
	}

	@Override
	public void approveMember(String enrollmentId, int size) throws Exception {
		size--;
		batchDao.updateBatchSize(enrollmentId,size);
		enrollmentDao.approveMember(enrollmentId);
	}

	@Override

    public List<EnrollmentInfo> memberEnrollment(String userId) throws Exception {
		
		return enrollmentDao.memberEnrollment(userId);
	}
	@Override
	public Enrollment enrollMember(Enrollment enrollment) throws Exception {
		enrollment.setEnrollmentId(generateEnrollmentId());
		
		return userDao.enrollUser(enrollment);
		}
	@Override
	public EnrollmentInfo viewReceipt(String enrollmentId) throws CustomException,Exception {
		
		return enrollmentDao.viewReceipt(enrollmentId);
	}

}
