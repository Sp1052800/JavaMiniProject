package com.deccan.services;

import java.util.List;

import com.deccan.dto.AllPlansInfo;
import com.deccan.exception.CustomException;
import com.deccan.model.Plan;

public interface IPlanService {
	public List<AllPlansInfo> displayPlans() throws CustomException, Exception ;
	public int addPlan(Plan plan) throws Exception;
	public Plan update(Plan plan) throws Exception;
	public int removePlan(String planId) throws Exception;
	public Plan getPlan(String planId) throws Exception;
//	String getplanId(String planName) throws Exception;
}
