package com.deccan.services;
import java.util.List;

import com.deccan.dto.EnrollmentInfo;
import com.deccan.exception.CustomException;
import com.deccan.model.Enrollment;

public interface IEnrollmentService {
	public List<EnrollmentInfo> displayEnrollments() throws Exception;
	public void approveMember(String enrollmentId, int size) throws Exception;
	public void rejectMember(String enrollmentId) throws Exception;

	public List<EnrollmentInfo> memberEnrollment(String userId) throws Exception;

	public Enrollment enrollMember(Enrollment enrollment) throws Exception;
	public EnrollmentInfo viewReceipt(String parameter) throws CustomException, Exception;

}
