package com.deccan.services;

import java.util.List;

import com.deccan.dao.BatchDaoImpl;
import com.deccan.dto.BatchList;
import com.deccan.model.Batch;

public class BatchService implements IBatchService{
	BatchDaoImpl batchDao = new BatchDaoImpl();
	private String generateBatchId() {
		return "DB"+Math.round(Math.random()*99999);
	}

	@Override
	public List<BatchList> displayBatches() throws Exception {

		List<BatchList> batchList = batchDao.displayBatches();
		return batchList;

	}

	@Override
	public Batch addBatch(Batch batch) throws Exception {
		
		batch.setBatchId(generateBatchId());
		
		return batchDao.addBatch(batch);
		
	}

	@Override
	public Batch updateBatch(Batch batch) throws Exception {
		return batchDao.updateBatch(batch);
		
	}

	@Override
	public int removeBatch(String batchId) throws Exception {
		return batchDao.removeBatch(batchId);
		
	}

	@Override
	public Batch getBatchById(String batchId) throws Exception {
		Batch batch=batchDao.getBatchById(batchId);
		return batch;
	}
	
	
	
}
