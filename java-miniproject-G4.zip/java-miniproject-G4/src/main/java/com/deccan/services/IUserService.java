package com.deccan.services;

import java.time.LocalTime;
import java.util.List;

import com.deccan.dto.AllPlansInfo;
import com.deccan.exception.CustomException;
import com.deccan.model.Batch;
import com.deccan.model.Plan;
import com.deccan.model.User;

public interface IUserService {
	public User register(User user) throws CustomException, Exception;

	public User login(String email, String password) throws CustomException;
	
	


	public User updateUser(User user) throws Exception;

	public String logout(String userId);

	public List<User> displayUsers() throws CustomException;

	public List<User> displayManagers() throws Exception;

	public int removeManager(String userId) throws Exception;

	public void userActivity();
	public User getUser(String userId) throws Exception;
	public User getUserByEmail(String userEmail) throws Exception;
	public User updateManager(User user) throws Exception;
	public List<AllPlansInfo> displayPlans()throws Exception;

	public User addManager(User user) throws Exception;
	public Plan getPlanByPlanId(String planId)throws Exception;
	public List<Batch> getAllBatches() throws Exception;
	public Batch getBatchIdByBatchTime(LocalTime startTime) throws Exception;
}
