package com.deccan.services;

import java.time.LocalTime;
import java.util.List;

import com.deccan.dao.IBatchDao;
import com.deccan.dao.IEnrollmentDao;
import com.deccan.dao.IPlanDao;
import com.deccan.dao.ISportDao;
import com.deccan.dao.IUserDao;
import com.deccan.dao.UserDaoImpl;
import com.deccan.dto.AllPlansInfo;
import com.deccan.exception.CustomException;
import com.deccan.model.Batch;
import com.deccan.model.Plan;
import com.deccan.model.User;

public class UserService implements IUserService {

	

	private IUserDao userDao = new UserDaoImpl();
	private IPlanDao planDao;
	private IBatchDao batchDao;
	private IEnrollmentDao enrollmentDao;
	private ISportDao sportDao;

	private String generateUserId() {
		return "DU" + Math.round(Math.random() * 99999);
	}

	@Override
	public User register(User user) throws Exception {
		System.out.println("In userService implementation  " + user);
		user.setUserId(generateUserId());
		//user.setRole("member");
		

		return userDao.register(user);
	}

	
	
	@Override
	public User login(String email, String password) throws CustomException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User updateUser(User user) throws Exception {
		return userDao.updateUser(user);
	}

	@Override
	public String logout(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<User> displayUsers() throws CustomException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<User> displayManagers() throws Exception {
		// TODO Auto-generated method stub
		return userDao.displayManagers();
	}

	@Override
	public int removeManager(String userId) throws Exception {
		return userDao.removeManager(userId);

	}

	@Override
	public void userActivity() {
		// TODO Auto-generated method stub

	}

	@Override
	public User getUser(String userId) throws Exception {
		// TODO Auto-generated method stub
		return userDao.getUser(userId);
	}


	@Override
	public User updateManager(User user) throws Exception {
		return userDao.updateManager(user);
		
	}

	@Override
	public List<AllPlansInfo> displayPlans() throws Exception {
		System.out.println("In userservice planlist ");
		return userDao.displayPlanlist();
	}

	@Override
	public User getUserByEmail(String userEmail) throws Exception {
		return userDao.getUserByEmail(userEmail);
	}
	
	@Override
	public User addManager(User user) throws Exception {
		user.setUserId(generateUserId());
		return userDao.addManager(user);
		
	}
	

	@Override
	public Plan getPlanByPlanId(String planId) throws Exception {
		return userDao.getPlanByPlanId(planId);
		
	}

	@Override
	public List<Batch> getAllBatches() throws Exception {
		return userDao.getAllBatches();
		
	}

	
	
	@Override
	public Batch getBatchIdByBatchTime(LocalTime startTime) throws Exception {
		return userDao.getBatchIdByBatchTime(startTime);
		

	}

}
