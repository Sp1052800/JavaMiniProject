package com.deccan.services;

import java.util.List;

import com.deccan.dao.IPlanDao;
import com.deccan.dao.PlanDaoImpl;
import com.deccan.dto.AllPlansInfo;
import com.deccan.model.Plan;

public class PlanService implements IPlanService{
	 IPlanDao planDao = new PlanDaoImpl();
	
	private String generatePlanId() {
		return "DP"+Math.round(Math.random()*99999);
	}

	@Override
	public List<AllPlansInfo> displayPlans() throws Exception {
		
		return planDao.displayPlans();
	}

	@Override
	public int addPlan(Plan plan) throws Exception {
		plan.setPlanId(generatePlanId());
		
		return planDao.addPlan(plan);
	}

	@Override
	public Plan update(Plan plan) throws Exception {
		
		return planDao.update(plan);
	}

	@Override
	public int removePlan(String planId) throws Exception {
		return planDao.removePlan(planId);
		
	}

	@Override
	public Plan getPlan(String planId) throws Exception {
		
		return planDao.getPlan(planId);
	}
	
//	@Override
//	public String getplanId(String planName) throws Exception {
//		
//		return planDao.getPlanId(planName);
//	
//		
//	}

	
	
	

}
