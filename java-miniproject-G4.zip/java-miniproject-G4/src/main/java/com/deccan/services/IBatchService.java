package com.deccan.services;

import java.util.List;

import com.deccan.dto.BatchList;
import com.deccan.exception.CustomException;
import com.deccan.model.Batch;

public interface IBatchService {
	public List<BatchList> displayBatches() throws CustomException, Exception;
	public Batch addBatch(Batch batch) throws Exception;
	public Batch updateBatch(Batch batch) throws Exception;
	public int removeBatch(String batchId) throws Exception;
	public Batch getBatchById(String batchId) throws Exception;
}
