package com.deccan.model;

import java.time.LocalTime;

public class Batch {
	private String batchId;
	private LocalTime startTime;
	private String batchDuration;
	private int size;
	private String sportsId;
	public Batch() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	public Batch(String batchId, LocalTime startTime, String batchDuration, int size, String sportId) {
		super();
		this.batchId = batchId;
		this.startTime = startTime;
		this.batchDuration = batchDuration;
		this.size = size;
		this.sportsId = sportId;
	}

	public Batch(String batchId, LocalTime startTime) {
		super();
		this.batchId = batchId;
		this.startTime = startTime;
	}
	public String getBatchId() {
		return batchId;
	}


	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}


	public LocalTime getStartTime() {
		return startTime;
	}


	public void setStartTime(LocalTime startTime) {
		this.startTime = startTime;
	}


	public String getBatchDuration() {
		return batchDuration;
	}


	public void setBatchDuration(String batchDuration) {
		this.batchDuration = batchDuration;
	}


	public int getSize() {
		return size;
	}


	public void setSize(int size) {
		this.size = size;
	}


	public String getSportsId() {
		return sportsId;
	}


	public void setSportsId(String sportId) {
		this.sportsId = sportId;
	}


	@Override
	public String toString() {
		return "Batch [batchId=" + batchId + ", startTime=" + startTime + ", batchDuration=" + batchDuration + ", size="
				+ size + ", sportId=" + sportsId + "]";
	}


	
	
}
