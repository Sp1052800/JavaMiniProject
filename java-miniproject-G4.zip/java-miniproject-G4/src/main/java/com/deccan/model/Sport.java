package com.deccan.model;

public class Sport {
	private String sportsId;
	private String sportName;
	
	public Sport(String sportId, String sportName) {
		super();
		this.sportsId = sportId;
		this.sportName = sportName;
	}
	public String getSportsId() {
		return sportsId;
	}
	public void setSportsId(String sportId) {
		this.sportsId = sportId;
	}
	public String getSportName() {
		return sportName;
	}
	public void setSportName(String sportName) {
		this.sportName = sportName;
	}
	@Override
	public String toString() {
		return "Sport [sportId=" + sportsId + ", sportName=" + sportName + "]";
	}
	
}
