package com.deccan.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.HttpConstraint;
import javax.servlet.annotation.ServletSecurity;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.deccan.dto.AllPlansInfo;
import com.deccan.dto.EnrollmentInfo;
import com.deccan.exception.CustomException;
import com.deccan.model.Batch;
import com.deccan.model.Enrollment;
import com.deccan.model.Plan;
import com.deccan.model.User;
import com.deccan.services.EnrollmentService;
import com.deccan.services.IEnrollmentService;
import com.deccan.services.IUserService;
import com.deccan.services.UserService;

@ServletSecurity(value = @HttpConstraint(rolesAllowed = { "member" }))
public class MemberController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static final Logger logger = LogManager.getLogger(MemberController.class.getName());
	IUserService userService = new UserService();

	IEnrollmentService enrollmentService = new EnrollmentService();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String path = request.getPathInfo();
		if (path.equals("/viewProfile")) {
			try {

				User user = userService.getUserByEmail(request.getRemoteUser());
				request.setAttribute("user", user);
				System.out.println(user);
				request.getRequestDispatcher("/member/member-viewprofile.jsp").forward(request, response);
			} catch (CustomException e) {
				logger.info(e.getLocalizedMessage());
			} catch (Exception e) {
				logger.info(e.getLocalizedMessage());
			}
		}

		if (path.equals("/planlist")) {
			try {
				List<AllPlansInfo> planlist = userService.displayPlans();
				request.setAttribute("plans", planlist);
				request.getRequestDispatcher("/member/member-planlist.jsp").forward(request, response);

			} catch (CustomException e) {
				logger.info(e.getLocalizedMessage());
			} catch (Exception e) {
				logger.info(e.getLocalizedMessage());
			}
		}

		if (path.equals("/updateMemberProfile")) {
			try {
				User user = new User();
				System.out.println(user);
				user.setUserId(request.getParameter("userId"));
				user.setUserName(request.getParameter("userName"));
				user.setUserEmail(request.getParameter("userEmail"));
				user.setPassword(request.getParameter("password"));
				user.setRole("member");
				user.setAddress(request.getParameter("address"));
				user.setContact(request.getParameter("contact"));

				userService.updateUser(user);
				HttpSession session = request.getSession();
				session.setAttribute("updatemsg", "User profile updated successfully");
				request.getRequestDispatcher("/member/member-home.jsp").forward(request, response);
			} catch (CustomException e) {
				logger.info(e.getLocalizedMessage());
			} catch (Exception e) {
				logger.info(e.getLocalizedMessage());
			}
		}

		if (path.equals("/buyMembership")) {
			try {

				Plan plan = userService.getPlanByPlanId(request.getParameter("planId"));
				System.out.println(request.getParameter("planId"));
				System.out.println(plan);
				List<Batch> batches = userService.getAllBatches();

				request.setAttribute("batches", batches);
				request.setAttribute("plan", plan);

				request.getRequestDispatcher("/member/member-enrollmentform.jsp").forward(request, response);
			} catch (CustomException e) {
				logger.info(e.getLocalizedMessage());
			} catch (Exception e) {
				logger.info(e.getLocalizedMessage());
			}
		}
		if (path.equals("/enrolluser")) {
			try {

				User user = new User();

				Plan plan = new Plan();
				Batch b = new Batch();

				plan = (Plan) request.getAttribute("plan");

				plan = userService.getPlanByPlanId(request.getParameter("planId"));
				user = userService.getUserByEmail(request.getRemoteUser());

				request.getAttribute("batches");
				b = userService.getBatchIdByBatchTime(LocalTime.parse(request.getParameter("batchTime")));
				Enrollment enroll = new Enrollment(user, b, plan, LocalDate.parse(request.getParameter("date")),
						"PENDING");

				enrollmentService.enrollMember(enroll);

				response.sendRedirect("planlist");
			} catch (CustomException e) {
				logger.info(e.getLocalizedMessage());
			} catch (Exception e) {
				logger.info(e.getLocalizedMessage());
			}
		}
		if (path.equals("/member-enrollments")) {
			try {
				User user = userService.getUserByEmail(request.getRemoteUser());
				List<EnrollmentInfo> memberEnrollments = enrollmentService.memberEnrollment(user.getUserId());
				request.setAttribute("enrollments", memberEnrollments);
				request.getRequestDispatcher("/member/member-viewenrollment.jsp").forward(request, response);

			} catch (CustomException e) {
				logger.info(e.getLocalizedMessage());
			} catch (Exception e) {
				logger.info(e.getLocalizedMessage());
			}
		}
		if (path.equals("/view-receipt")) {
			try {
				User user = userService.getUserByEmail(request.getRemoteUser());
				EnrollmentInfo enrollmentInfo = enrollmentService.viewReceipt(request.getParameter("enrollmentId"));
				System.out.println(enrollmentInfo.toString());
				request.setAttribute("enrollmentinfo", enrollmentInfo);
				request.getRequestDispatcher("/member/member-viewreceipt.jsp").forward(request, response);

			} catch (CustomException e) {
				logger.info(e.getLocalizedMessage());
			} catch (Exception e) {
				logger.info(e.getLocalizedMessage());
			}
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}
