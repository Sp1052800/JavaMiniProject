package com.deccan.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.HttpConstraint;
import javax.servlet.annotation.ServletSecurity;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.deccan.exception.CustomException;
import com.deccan.model.User;
import com.deccan.services.IUserService;
import com.deccan.services.UserService;

//only admin will be able to access this servlet
@ServletSecurity(value = @HttpConstraint(rolesAllowed = { "admin" }))
public class AdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static final Logger logger = LogManager.getLogger(AdminController.class.getName());
	IUserService userService = new UserService();

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// getting path
		String path = request.getPathInfo();
		// to add manager
		if (path.equals("/addmanager")) {
			try {
				logger.info("Adding manager");
				User user = new User();
				user.setUserName(request.getParameter("userName"));
				user.setUserEmail(request.getParameter("userEmail"));
				user.setPassword(request.getParameter("password"));
				user.setRole(request.getParameter("role"));
				user.setContact(request.getParameter("contact"));
				user.setAddress(request.getParameter("address"));
				userService.addManager(user);
				HttpSession session = request.getSession();
				session.setAttribute("addmanagermsg", "Manager added successfully");
				response.sendRedirect("managerlist");
			} catch (CustomException e) {
				logger.info(e.getLocalizedMessage());
			} catch (Exception e) {
				logger.info(e.getLocalizedMessage());
			}
		}
		// to display list of manager
		if (path.equals("/managerlist")) {
			try {
				logger.info("Processing list manager ");
				List<User> users = userService.displayManagers();
				request.setAttribute("users", users);
				request.getRequestDispatcher("/admin/admin-managerlist.jsp").forward(request, response);
			} catch (CustomException e) {
				logger.info(e.getLocalizedMessage());
			} catch (Exception e) {
				logger.info(e.getLocalizedMessage());
			}
		}
		// to edit/update manager
		if (path.equals("/editmanager")) {
			try {
				logger.info("In editing user ");
				User user = userService.getUser(request.getParameter("userId"));
				request.setAttribute("user", user);
				request.getRequestDispatcher("/admin/admin-updatemanagerlist.jsp").forward(request, response);
			} catch (CustomException e) {
				logger.info(e.getLocalizedMessage());
			} catch (Exception e) {
				logger.info(e.getLocalizedMessage());
			}
		}
		if (path.equals("/updatemanager")) {
			try {
				User user = new User();
				user.setUserId(request.getParameter("userId"));
				user.setUserName(request.getParameter("userName"));
				user.setUserEmail(request.getParameter("userEmail"));
				user.setPassword(request.getParameter("password"));
				user.setRole(request.getParameter("role"));
				user.setContact(request.getParameter("contact"));
				user.setAddress(request.getParameter("address"));
				System.out.println(user.toString());

				userService.updateManager(user);
				HttpSession session = request.getSession();
				session.setAttribute("updatemanagermsg", "Manager profile updated successfully");
				response.sendRedirect("managerlist");
			} catch (CustomException e) {
				logger.info(e.getLocalizedMessage());
			} catch (Exception e) {
				logger.info(e.getLocalizedMessage());
			}
		}
		// to delete manager
		if (path.equals("/deletemanager")) {
			try {
				userService.removeManager(request.getParameter("userId"));
				HttpSession session = request.getSession();
				session.setAttribute("deletemanagermsg", "Manager deleted successfully");
				response.sendRedirect("managerlist");
			} catch (CustomException e) {
				logger.info(e.getLocalizedMessage());
			} catch (Exception e) {
				logger.info(e.getLocalizedMessage());
			}
		}

	}
}
