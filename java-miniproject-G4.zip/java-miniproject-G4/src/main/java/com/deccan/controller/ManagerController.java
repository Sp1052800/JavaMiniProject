package com.deccan.controller;

import java.io.IOException;
import java.time.LocalTime;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.HttpConstraint;
import javax.servlet.annotation.ServletSecurity;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.deccan.dto.AllPlansInfo;
import com.deccan.dto.BatchList;
import com.deccan.dto.EnrollmentInfo;
import com.deccan.exception.CustomException;
import com.deccan.model.Batch;
import com.deccan.model.Plan;
import com.deccan.model.Sport;
import com.deccan.services.BatchService;
import com.deccan.services.EnrollmentService;
import com.deccan.services.IBatchService;
import com.deccan.services.IEnrollmentService;
import com.deccan.services.IPlanService;
import com.deccan.services.ISportService;
import com.deccan.services.PlanService;
import com.deccan.services.SportService;
//only manager will be able to access this controller
@ServletSecurity(value = @HttpConstraint(rolesAllowed = { "manager" }))

public class ManagerController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static final Logger logger = LogManager.getLogger(AdminController.class.getName());
	IPlanService planService = new PlanService();
	ISportService sportService = new SportService();
	IBatchService batchService = new BatchService();
	IEnrollmentService enrollmentService = new EnrollmentService();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//to display list of plans
		String path = request.getPathInfo();
		if (path.equals("/listplan")) {
			try {
				List<AllPlansInfo> plans = planService.displayPlans();
				List<Sport> sports;
				sports = sportService.displaySports();
				request.setAttribute("plans", plans);
				request.setAttribute("sports", sports);

				request.getRequestDispatcher("/manager/manager-planlist.jsp").forward(request, response);
			} catch (CustomException e) {
				logger.info(e.getLocalizedMessage());
			} catch (Exception e) {
				logger.info(e.getLocalizedMessage());
			}

		}

		if (path.equals("/addplan")) {

			try {

				Plan plan = new Plan();
				plan.setPlanName(request.getParameter("planname"));
				plan.setSportsId(request.getParameter("sportid"));
				plan.setFees(Double.parseDouble(request.getParameter("fees")));
				plan.setDuration((request.getParameter("duration")));
				planService.addPlan(plan);
				HttpSession session = request.getSession();
				session.setAttribute("addplanmsg", "plan added successfully");
				response.sendRedirect("listplan");
			} catch (CustomException e) {
				logger.info(e.getLocalizedMessage());
			} catch (Exception e) {
				logger.info(e.getLocalizedMessage());
			}
		}
		if (path.equals("/editplan")) {
			try {

				Plan plan = planService.getPlan(request.getParameter("planid"));
				request.setAttribute("plan", plan);
				List<Sport> sports;
				sports = sportService.displaySports();
				request.setAttribute("sports", sports);
				request.getRequestDispatcher("/manager/manager-updateplan.jsp").forward(request, response);

			} catch (CustomException e) {
				logger.info(e.getLocalizedMessage());
			} catch (Exception e) {
				logger.info(e.getLocalizedMessage());
			}
		}
		if (path.equals("/updateplan")) {
			try {
				Plan plan = new Plan();
				plan.setPlanId(request.getParameter("planid"));
				;
				plan.setPlanName(request.getParameter("planname"));
				plan.setSportsId(request.getParameter("sportid"));
				plan.setFees(Double.parseDouble(request.getParameter("fees")));
				plan.setDuration((request.getParameter("duration")));
				planService.update(plan);
				HttpSession session = request.getSession();
				session.setAttribute("updateplanmsg", "Plan updated successfully");
				response.sendRedirect("listplan");
			} catch (CustomException e) {
				logger.info(e.getLocalizedMessage());
			} catch (Exception e) {
				logger.info(e.getLocalizedMessage());
			}
		}
		if (path.equals("/deleteplan")) {
			try {
				planService.removePlan(request.getParameter("planid"));

				HttpSession session = request.getSession();
				session.setAttribute("deleteplanmsg", "plan deleted successfully");
				response.sendRedirect("listplan");

			} catch (CustomException e) {
				logger.info(e.getLocalizedMessage());
			} catch (Exception e) {
				logger.info(e.getLocalizedMessage());
			}
		}

		if (path.equals("/batch-list")) {

			try {

				List<BatchList> listOfBatches = batchService.displayBatches();
				request.setAttribute("batchList", listOfBatches);
				request.getRequestDispatcher("/manager/manager-batchlist.jsp").forward(request, response);

			} catch (CustomException e) {
				logger.info(e.getLocalizedMessage());
			} catch (Exception e) {
				logger.info(e.getLocalizedMessage());
			}
		}

		if (path.equals("/sport-list")) {
			try {
				List<Sport> sportList = sportService.displaySports();
				request.setAttribute("sports", sportList);
				request.getRequestDispatcher("/manager/manager-addbatch.jsp").forward(request, response);
			} catch (CustomException e) {
				logger.info(e.getLocalizedMessage());
			} catch (Exception e) {
				logger.info(e.getLocalizedMessage());
			}
		}

		if (path.equals("/add-batch"))

			try {
				Batch batch = new Batch();
				batch.setStartTime(LocalTime.parse(request.getParameter("startTime")));
				batch.setBatchDuration(request.getParameter("batchDuration"));
				batch.setSize(Integer.parseInt(request.getParameter("size")));
				batch.setSportsId(request.getParameter("sportId"));
				batchService.addBatch(batch);
				HttpSession session = request.getSession();
				session.setAttribute("addbatchmsg", "Batch added successfully");
				response.sendRedirect("batch-list");

			} catch (CustomException e) {
				logger.info(e.getLocalizedMessage());
			} catch (Exception e) {
				logger.info(e.getLocalizedMessage());
			}

		if (path.equals("/sportslist")) {
			try {
				List<Sport> sportList = sportService.displaySports();
				request.setAttribute("sportslist", sportList);
				request.getRequestDispatcher("/manager/manager-addplan.jsp").forward(request, response);
			} catch (CustomException e) {
				logger.info(e.getLocalizedMessage());
			} catch (Exception e) {
				logger.info(e.getLocalizedMessage());
			}
		}
		if (path.equals("/edit-batch")) {
			try {
				List<Sport> sportList = sportService.displaySports();
				request.setAttribute("sports", sportList);
				String batchId = request.getParameter("batchId");
				Batch batch = batchService.getBatchById(batchId);
				request.setAttribute("batch", batch);
				request.getRequestDispatcher("/manager/manager-updatebatch.jsp").include(request, response);
				;

			} catch (CustomException e) {
				logger.info(e.getLocalizedMessage());
			} catch (Exception e) {
				logger.info(e.getLocalizedMessage());
			}
		}
		if (path.equals("/update-batch")) {
			try {
				Batch updatedBatch = new Batch();
				updatedBatch.setBatchId(request.getParameter("batchId"));
				updatedBatch.setStartTime(LocalTime.parse(request.getParameter("startTime")));
				updatedBatch.setBatchDuration(request.getParameter("batchDuration"));
				updatedBatch.setSize(Integer.parseInt(request.getParameter("size")));
				updatedBatch.setSportsId(request.getParameter("sportsId"));
				batchService.updateBatch(updatedBatch);
				HttpSession session = request.getSession();
				session.setAttribute("updatebatchmsg", "Batch updated successfully");
				response.sendRedirect("batch-list");

			} catch (CustomException e) {
				logger.info(e.getLocalizedMessage());
			} catch (Exception e) {
				logger.info(e.getLocalizedMessage());
			}
		}
		if (path.equals("/delete-batch")) {

			try {
				String batchId = request.getParameter("batchId");
				batchService.removeBatch(batchId);
				HttpSession session = request.getSession();
				session.setAttribute("deletebatchmsg", "batch deleted successfully");
				response.sendRedirect("batch-list");

			} catch (CustomException e) {
				logger.info(e.getLocalizedMessage());
			} catch (Exception e) {
				logger.info(e.getLocalizedMessage());
			}
		}
		if (path.equals("/enrollmentlist")) {
			try {
				List<EnrollmentInfo> enrollments = enrollmentService.displayEnrollments();
				request.setAttribute("enrollments", enrollments);
				request.getRequestDispatcher("/manager/manager-enrollmentlist.jsp").forward(request, response);
			} catch (CustomException e) {
				logger.info(e.getLocalizedMessage());
			} catch (Exception e) {
				logger.info(e.getLocalizedMessage());
			}
		}

		if (path.equals("/approvemember")) {
			try {
				int size = Integer.parseInt(request.getParameter("size"));
				enrollmentService.approveMember(request.getParameter("enrollmentId"), size);
				response.sendRedirect("enrollmentlist");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		if (path.equals("/rejectmember")) {
			try {
				enrollmentService.rejectMember(request.getParameter("enrollmentId"));
				response.sendRedirect("enrollmentlist");
			} catch (CustomException e) {
				logger.info(e.getLocalizedMessage());
			} catch (Exception e) {
				logger.info(e.getLocalizedMessage());
			}
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}
