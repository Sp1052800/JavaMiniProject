package com.deccan.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.deccan.exception.CustomException;
import com.deccan.model.User;
import com.deccan.services.IUserService;
import com.deccan.services.UserService;

public class RegisterController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static final Logger logger = LogManager.getLogger(AdminController.class.getName());
	IUserService userService = new UserService();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String path = request.getPathInfo();
		if (path.equals("/registerMember")) {
			try {
				User user = new User();

				user.setUserName(request.getParameter("userName"));
				user.setUserEmail(request.getParameter("userEmail"));
				user.setPassword(request.getParameter("password"));
				user.setRole("member");
				user.setContact(request.getParameter("contact"));
				user.setAddress(request.getParameter("address"));
				userService.register(user);
				HttpSession session = request.getSession();
				session.setAttribute("registrationmsg", "You are registered successfully! Please Login!");
				request.getRequestDispatcher("/index.jsp").forward(request, response);
			} catch (CustomException e) {
				logger.info(e.getLocalizedMessage());
			} catch (Exception e) {
				logger.info(e.getLocalizedMessage());
			}
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		doGet(request, response);
	}

}
