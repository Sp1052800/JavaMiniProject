package com.deccan.dao;

import com.deccan.model.Enrollment;

import java.util.List;

import com.deccan.dto.EnrollmentInfo;

public interface IEnrollmentDao {

	public List<EnrollmentInfo> displayEnrollments() throws Exception;
	public void approveMember(String enrollmentId) throws Exception;
	public void rejectMember(String enrollmentId) throws Exception;
}
