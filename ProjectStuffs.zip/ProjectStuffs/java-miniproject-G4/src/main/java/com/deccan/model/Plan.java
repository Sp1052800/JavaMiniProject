package com.deccan.model;

public class Plan {
	private String planId;
	private String planName;
	private double fees;
	private String duration;
	private String sportsId;
	public Plan() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Plan(String planId, String planName, double fees, String duration, String sportsId) {
		super();
		this.planId = planId;
		this.planName = planName;
		this.fees = fees;
		this.duration = duration;
		this.sportsId = sportsId;
	}
	public String getPlanId() {
		return planId;
	}
	public void setPlanId(String planId) {
		this.planId = planId;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public double getFees() {
		return fees;
	}
	public void setFees(double fees) {
		this.fees = fees;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public String getSportId() {
		return sportsId;
	}
	public void setSportId(String sportsId) {
		this.sportsId =sportsId;
		
	}
	@Override
	public String toString() {
		return "Plan [planId=" + planId + ", planName=" + planName + ", fees=" + fees + ", duration=" + duration
				+ ", sportsId=" + sportsId + "]";
	}
	
	
}
