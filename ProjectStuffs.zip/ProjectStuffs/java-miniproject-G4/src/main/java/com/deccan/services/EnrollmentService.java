package com.deccan.services;

import java.util.List;

import com.deccan.dao.BatchDaoImpl;
import com.deccan.dao.EnrollmentDaoImpl;
import com.deccan.dao.IBatchDao;
import com.deccan.dao.IEnrollmentDao;
import com.deccan.dto.EnrollmentInfo;
import com.deccan.model.Enrollment;

public class EnrollmentService implements IEnrollmentService{
	
	IEnrollmentDao enrollmentDao = new EnrollmentDaoImpl();
	IBatchDao batchDao = new BatchDaoImpl();
	private String generateEnrollmentId() {
		return "DE"+Math.round(Math.random()*99999);
	}

	@Override
	public List<EnrollmentInfo> displayEnrollments() throws Exception {
		
		return enrollmentDao.displayEnrollments();
	}

	@Override
	public void rejectMember(String enrollmentId) throws Exception {
		enrollmentDao.rejectMember(enrollmentId);
		
	}

	@Override
	public void approveMember(String enrollmentId, int size) throws Exception {
		size--;
		batchDao.updateBatchSize(enrollmentId,size);
		enrollmentDao.approveMember(enrollmentId);
	}

	

	
}
