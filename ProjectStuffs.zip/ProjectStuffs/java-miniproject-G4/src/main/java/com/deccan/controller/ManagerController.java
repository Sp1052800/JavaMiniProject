package com.deccan.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.HttpConstraint;
import javax.servlet.annotation.ServletSecurity;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.deccan.exception.BatchException;
import com.deccan.model.Plan;
import com.deccan.model.Sport;
import com.deccan.services.PlanService;
import com.deccan.services.SportService;
import com.deccan.dto.BatchList;
import com.deccan.dto.EnrollmentInfo;
import com.deccan.dto.PlanFrom;
import com.deccan.services.BatchService;
import com.deccan.services.EnrollmentService;
import com.deccan.services.IEnrollmentService;
@ServletSecurity(value = @HttpConstraint(rolesAllowed = {  "manager" }))
public class ManagerController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	PlanService planService = new PlanService();
	SportService sportService = new SportService();
	BatchService batchService = new BatchService();
    IEnrollmentService enrollmentService = new EnrollmentService();
	public ManagerController() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String path = request.getPathInfo();
		if (path.equals("/listplan")) {
			try {

				List<PlanFrom> plans = planService.displayPlans();
				List<Sport> sports;
				sports = sportService.displaySports();
				sports.stream().forEach(System.out::println);
				request.setAttribute("plans", plans);
				request.setAttribute("sports", sports);

				request.getRequestDispatcher("/manager/manager-planlist.jsp").forward(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		if (path.equals("/addplan")) {

			try {
				
				Plan plan = new Plan();
				plan.setPlanName(request.getParameter("planname"));
				plan.setSportId(request.getParameter("sportid"));
				plan.setFees(Double.parseDouble(request.getParameter("fees")));
				plan.setDuration((request.getParameter("duration")));
				planService.addPlan(plan);
				response.sendRedirect("listplan");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (path.equals("/batch-list")) {

			try {

				List<BatchList> listOfBatches = batchService.displayBatches();
				request.setAttribute("batchList", listOfBatches);
				request.getRequestDispatcher("/manager/manager-batchlist.jsp").forward(request, response);

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();

			}
		}
		
		if(path.equals("/enrollmentlist")) {			
			try {
				List<EnrollmentInfo> enrollments =  enrollmentService.displayEnrollments();
				request.setAttribute("enrollments", enrollments);
				request.getRequestDispatcher("/manager/manager-enrollmentlist.jsp").forward(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if(path.equals("/approvemember")) {			
			try {
				int size=Integer. parseInt(request.getParameter("size"));
				System.out.println(size);
				enrollmentService.approveMember(request.getParameter("enrollmentId"),size);
				response.sendRedirect("enrollmentlist");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if(path.equals("/rejectmember")) {			
			try {
				enrollmentService.rejectMember(request.getParameter("enrollmentId"));
				response.sendRedirect("enrollmentlist");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
