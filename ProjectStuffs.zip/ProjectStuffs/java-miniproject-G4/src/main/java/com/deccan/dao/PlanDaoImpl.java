package com.deccan.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.deccan.dbutils.DbUtil;
import com.deccan.dto.PlanFrom;
import com.deccan.model.Plan;

public class PlanDaoImpl implements IPlanDao {
	Connection connection = null;
	PreparedStatement ps = null;

	@Override
	public List<PlanFrom> displayPlans() throws Exception {
		String sql = "SELECT plans.planName, sports.sportName, plans.fees, plans.duration" + "FROM plans"
				+ "INNER JOIN sports ON plans.sportsId=sports.sportsId;";
		connection = DbUtil.getConnection();
		ps = connection.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();

		List<PlanFrom> plan = new ArrayList<PlanFrom>();
		while (rs.next()) {
			System.out.println(rs.getString(3));
			plan.add(new PlanFrom(rs.getString(1), rs.getString(2), rs.getDouble(3), rs.getInt(4)));

		}
		return plan;
	}

	@Override
	public int addPlan(Plan plan) throws Exception {
		String sql = "insert into plans values(?, ?, ?,?,?)";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);

		ps.setString(1, plan.getPlanId());
		ps.setString(2, plan.getPlanName());
		ps.setString(3, plan.getSportId());
		ps.setDouble(4, plan.getFees());
		ps.setString(5, plan.getDuration());

//		ResultSet rs = ps.executeQuery();

		return ps.executeUpdate();
	}

	@Override
	public Plan update(Plan plan) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void removePlan(String planId) {
		// TODO Auto-generated method stub

	}

}
