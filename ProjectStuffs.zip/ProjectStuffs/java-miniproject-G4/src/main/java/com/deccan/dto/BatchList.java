package com.deccan.dto;

import java.time.LocalTime;

public class BatchList {
	private String batchId;
	private LocalTime startTime;
	private String batchDuration;
	private int size;
	private String sportName;

	public BatchList() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BatchList(String batchId, LocalTime startTime, String batchDuration, int size, String sportName) {
		super();
		this.batchId = batchId;
		this.startTime = startTime;
		this.batchDuration = batchDuration;
		this.size = size;
		this.sportName = sportName;
	}

	public String getBatchId() {
		return batchId;
	}

	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}

	public String getBatchDuration() {
		return batchDuration;
	}

	public void setBatchDuration(String batchDuration) {
		this.batchDuration = batchDuration;
	}

	public LocalTime getStartTime() {
		return startTime;
	}

	public void setStartTime(LocalTime startTime) {
		this.startTime = startTime;
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public String getSportName() {
		return sportName;
	}

	public void setSportName(String sportName) {
		this.sportName = sportName;
	}

	@Override
	public String toString() {
		return "BatchList [batchId=" + batchId + ", startTime=" + startTime + ", batchDuration=" + batchDuration
				+ ", size=" + size + ", sportName=" + sportName + "]";
	}

}
