package com.deccan.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.deccan.dbutils.DbUtil;
import com.deccan.model.Plan;
import com.deccan.model.Sport;

public class SportDaoImpl implements ISportDao{

	Connection connection =null;
	PreparedStatement ps=null;
	@Override
	public List<Sport> displaySports() throws Exception {
		String sql = "select * from sports";
		connection = DbUtil.getConnection();
		ps = connection.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();

		List<Sport> sport = new ArrayList<Sport>();
		while(rs.next()) {
			
			sport.add(new Sport(rs.getString(1), rs.getString(2)));
			
		}
		return sport;
		
	}

	@Override
	public Sport addSport(Sport sport) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Sport updateSport(Sport sport) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void removeSport(String sportId) {
		// TODO Auto-generated method stub
		
	}

}
