package com.deccan.dto;

public class PlanFrom {
	private String planName;
	private String sportName;
	private double fees;
	private int duration;
	
	
	
	public PlanFrom(String planName, String sportName, double fees, int duration) {
		super();
		this.planName = planName;
		this.sportName = sportName;
		this.fees = fees;
		this.duration = duration;
	}
	public PlanFrom() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public String getSportName() {
		return sportName;
	}
	public void setSportName(String sportName) {
		this.sportName = sportName;
	}
	public double getFees() {
		return fees;
	}
	public void setFees(double fees) {
		this.fees = fees;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	
	
}
