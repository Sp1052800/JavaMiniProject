package com.deccan.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import java.util.List;

import com.deccan.dbutils.DbUtil;
import com.deccan.exception.UserException;
import com.deccan.model.AllPlansInfo;
import com.deccan.model.User;

public class UserDaoImpl implements IUserDao {

	public UserDaoImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public User register(User user) throws Exception {
		System.out.println("In UserDao impl " + user);
		String sql = "insert into users values(?,?,?,?,?,?,?)";
		Connection con = DbUtil.getConnection();
		con.setAutoCommit(false);
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, user.getUserId());
		ps.setString(2, user.getUserName());
		ps.setString(3, user.getUserEmail());
		ps.setString(4, user.getPassword());
		ps.setString(5, user.getRole());
		ps.setString(6, user.getContact());
		ps.setString(7, user.getAddress());

		if (ps.executeUpdate() == 1) {
			con.commit(); // user will be committed
			ps.close();
			con.close();
			return user;
		} else {
			con.rollback();
			ps.close();
			con.close();
			return null;
		}

	}

	@Override
	public User login(String email, String password) throws UserException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String logout(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User updateUser(User user) throws Exception {
		String sql = "update users set userName=?, userEmail=?, password = ? , role = ?, contact=?,address=? where userId = ?";
		Connection connection = DbUtil.getConnection();
		connection.setAutoCommit(false);
		PreparedStatement ps = connection.prepareStatement(sql);		
		ps.setString(1, user.getUserName());
		ps.setString(2, user.getUserEmail());
		ps.setString(3, user.getPassword());
		ps.setString(4, user.getRole());
		ps.setString(5, user.getContact());
		ps.setString(6, user.getAddress());
		ps.setString(7, user.getUserId());
		
		if(ps.executeUpdate() == 1) {
			connection.commit();			//user  will be committed
			ps.close(); 
			connection.close();  
			return user;
		}
		else{ 
			connection.rollback();
			ps.close(); 
			connection.close(); 
			return null;
		}
	}

	@Override
	public List<User> displayUsers() throws UserException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override

	public List<User> displayManagers() throws Exception {
		String sql = "select * from users where role = ?";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ps.setString(1, "manager");
		ResultSet rs = ps.executeQuery();

		List<User> users = new ArrayList<User>();
		while (rs.next()) {
			users.add(new User(rs.getString("userId"), rs.getString("userName"), rs.getString("userEmail"),
					rs.getString("password"), rs.getString("role"), rs.getString("contact"), rs.getString("address")));
			System.out.println(users.toString());
		}
		return users;

	}

	@Override
	public int removeManager(String userId) throws Exception {

		String sql = "delete from users where userId = ?";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ps.setString(1, userId);

		return ps.executeUpdate();

	}
	
	@Override
	public User getUser(String userId) throws Exception {
		String sql = "select * from users where userId = ?";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ps.setString(1, userId);
		ResultSet rs = ps.executeQuery();
		User  user = null;
		if(rs.next()) {
			user = new User(rs.getString(1),rs.getString(2), rs.getString(3), rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7));
		}
		return user;
	}

	@Override
	public User updateManager(User user) throws Exception {
		System.out.println("In UserDao impl " + user);
		String sql = "update users set userName=?, userEmail=?, password=?, role=?, contact=?, address=? where userId=?";
		Connection con = DbUtil.getConnection();
		con.setAutoCommit(false);
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, user.getUserName());
		ps.setString(2, user.getUserEmail());
		ps.setString(3, user.getPassword());
		ps.setString(4, user.getRole());
		ps.setString(5, user.getContact());
		ps.setString(6, user.getAddress());
		ps.setString(7, user.getUserId());
		if (ps.executeUpdate() == 1) {
			con.commit(); // user will be committed
			ps.close();
			con.close();
			return user;
		} else {
			con.rollback();
			ps.close();
			con.close();
			return null;
		}

	}

	@Override
	public List<AllPlansInfo> displayPlanlist() throws Exception {
		System.out.println("In user dao planlist");
		String sql="select p.planId,s.sportsId,p.planName,p.fees,p.duration,s.sportName from plans p inner join sports s on s.sportsId=p.sporstId";
		Connection con= DbUtil.getConnection();
		PreparedStatement ps= con.prepareStatement(sql);
		List<AllPlansInfo>list = new ArrayList<AllPlansInfo>();
		ResultSet rs= ps.executeQuery();
		while(rs.next()) {
			list.add(new AllPlansInfo(rs.getString("planId"), rs.getString("sportsId"), rs.getString("planName"), rs.getDouble("fees"), rs.getInt("duration"), rs.getString("sportName")));
		}
		
		return list;
	
	}

	@Override
	public User getUserByEmail(String userEmail) throws Exception {
		String sql = "select * from users where userEmail = ?";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ps.setString(1, userEmail);
		ResultSet rs = ps.executeQuery();
		User  user = null;
		if(rs.next()) {
			user = new User(rs.getString(1),rs.getString(2), rs.getString(3), rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7));
		}
		return user;
	}
	public User addManager(User user) throws Exception {
		System.out.println("In UserDao impl " + user);
		String sql = "insert into users values(?,?,?,?,?,?,?)";
		Connection con = DbUtil.getConnection();
		con.setAutoCommit(false);
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, user.getUserId());
		ps.setString(2, user.getUserName());
		ps.setString(3, user.getUserEmail());
		ps.setString(4, user.getPassword());
		ps.setString(5, user.getRole());
		ps.setString(6, user.getContact());
		ps.setString(7, user.getAddress());

		if (ps.executeUpdate() == 1) {
			con.commit(); // user will be committed
			ps.close();
			con.close();
			return user;
		} else {
			con.rollback();
			ps.close();
			con.close();
			return null;
		}
	}
}
