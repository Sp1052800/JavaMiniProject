package com.deccan.services;

import java.util.List;

import com.deccan.dto.EnrollmentInfo;
import com.deccan.model.Enrollment;

public interface IEnrollmentService {
	public List<EnrollmentInfo> displayEnrollments() throws Exception;
	public void approveMember(String enrollmentId, int size) throws Exception;
	public void rejectMember(String enrollmentId) throws Exception;
}
