package com.deccan.services;

import java.util.List;

import com.deccan.dto.BatchList;
import com.deccan.exception.BatchException;
import com.deccan.model.Batch;

public interface IBatchService {
	public List<BatchList> displayBatches() throws BatchException, Exception;
	public Batch addBatch(Batch batch);
	public Batch updateBatch(Batch batch);
	public void removeBatch(String batchId);
}
