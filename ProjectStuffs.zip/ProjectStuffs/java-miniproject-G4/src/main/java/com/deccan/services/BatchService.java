package com.deccan.services;

import java.util.List;

import com.deccan.dao.BatchDaoImpl;
import com.deccan.dto.BatchList;
import com.deccan.exception.BatchException;
import com.deccan.model.Batch;

public class BatchService implements IBatchService{
	BatchDaoImpl batchDao = new BatchDaoImpl();
	private String generateBatchId() {
		return "DB"+Math.round(Math.random()*99999);
	}

	@Override
	public List<BatchList> displayBatches() throws Exception {

		List<BatchList> batchList = batchDao.displayBatches();
		return batchList;

	}

	@Override
	public Batch addBatch(Batch batch) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Batch updateBatch(Batch batch) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void removeBatch(String batchId) {
		// TODO Auto-generated method stub
		
	}
	
	
	
}
