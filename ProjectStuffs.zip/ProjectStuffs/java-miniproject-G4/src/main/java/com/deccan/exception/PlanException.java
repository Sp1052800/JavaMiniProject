package com.deccan.exception;

public class PlanException extends Exception {

	public PlanException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}

	
}
