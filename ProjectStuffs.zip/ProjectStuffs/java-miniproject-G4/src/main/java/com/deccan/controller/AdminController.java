package com.deccan.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.deccan.model.User;
import com.deccan.services.IUserService;
import com.deccan.services.UserService;

/**
 * Servlet implementation class AdminServlet
 */
public class AdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	IUserService userService = new UserService();

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String path = request.getPathInfo();

		if (path.equals("/addmanager")) {
			try {
				System.out.println("hello");
				User user = new User();
				user.setUserName(request.getParameter("userName"));
				user.setUserEmail(request.getParameter("userEmail"));
				user.setPassword(request.getParameter("password"));
				user.setRole(request.getParameter("role"));
				user.setContact(request.getParameter("contact"));
				user.setAddress(request.getParameter("address"));
				userService.addManager(user);
				response.sendRedirect("managerlist");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		if (path.equals("/managerlist")) {
			try {
				List<User> users = userService.displayManagers();
				request.setAttribute("users", users);
				request.getRequestDispatcher("/admin/admin-managerlist.jsp").forward(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if(path.equals("/edituser")) {			
			try {
				User user = userService.getUser(request.getParameter("userId"));
			System.out.println(user.toString());
				request.setAttribute("user", user);
				request.getRequestDispatcher("/admin/admin-updatemanagerlist.jsp").forward(request, response);								
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if(path.equals("/updatemanager")) {			
			try {
				User user = new User();
				user.setUserId(request.getParameter("userId"));
				user.setUserName(request.getParameter("userName"));
				user.setUserEmail(request.getParameter("userEmail"));
				user.setPassword(request.getParameter("password"));
				user.setRole(request.getParameter("role"));
				user.setContact(request.getParameter("contact"));
				user.setAddress(request.getParameter("address"));
				System.out.println(user.toString());
				userService.updateManager(user);
				response.sendRedirect("managerlist");										
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		if (path.equals("/deleteuser")) {
			try {
				userService.removeManager(request.getParameter("userId"));
				// request.setAttribute("deletemsg", "User deleted successfully");
				HttpSession session = request.getSession();
				session.setAttribute("deletemsg", "User deleted successfully");
				response.sendRedirect("managerlist");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}
}
