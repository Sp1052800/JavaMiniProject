package com.deccan.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import com.deccan.dbutils.DbUtil;
import com.deccan.dto.BatchList;
import com.deccan.model.Batch;
import java.util.List;

import com.deccan.model.Batch;

public class BatchDaoImpl implements IBatchDao{

	@Override
	public List<BatchList> displayBatches() throws Exception {
		String sql= "SELECT batch.batchId,"
				+ "batch.startTime,  "
				+ "batch.batchDuration, "
				+ "batch.size,"
				+ "sports.sportName "
				+ "FROM batch "
				+ "INNER JOIN sports ON "
				+ "batch.sportsId=sports.sportsId;";
		
		Connection connection= DbUtil.getConnection();
		
		PreparedStatement preparedStatement= connection.prepareStatement(sql);
		ResultSet resultSet=preparedStatement.executeQuery();
		
		List<BatchList> listOfBatches = new ArrayList<BatchList>();
		
		while(resultSet.next()) {
			LocalTime createdTime = resultSet.getTime(2).toLocalTime();
			listOfBatches.add(new BatchList(resultSet.getString(1),
					createdTime,
					resultSet.getString(3),
					resultSet.getInt(4),
					resultSet.getString(5)
					));
		}
		
		
		return listOfBatches;
	}

	@Override
	public Batch addBatch(Batch batch) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Batch updateBatch(Batch batch) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void removeBatch(String batchId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateBatchSize(String enrollmentId, int size) throws Exception {
		String sql= "select batchId from enrollment where enrollmentId=?";
		Connection connection= DbUtil.getConnection();
		PreparedStatement ps= connection.prepareStatement(sql);
		ps.setString(1,enrollmentId);
		ResultSet rs=ps.executeQuery();
		String batchId=null;
		if(rs.next()) {
			batchId=rs.getString(1);
		}
		
		String sql1= "update batch set size=? where batchId=?";
		Connection con = DbUtil.getConnection();
		con.setAutoCommit(false);
		PreparedStatement ps1 = con.prepareStatement(sql1);
		ps1.setInt(1, size);
		ps1.setString(2, batchId);
		if (ps1.executeUpdate() == 1) {
			con.commit(); // user will be committed
			ps1.close();
			con.close();
		} else {
			con.rollback();
			ps1.close();
			con.close();
		}
	}

	

}
