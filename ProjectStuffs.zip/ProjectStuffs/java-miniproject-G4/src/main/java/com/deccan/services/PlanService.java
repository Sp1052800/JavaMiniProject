package com.deccan.services;

import java.util.List;

import com.deccan.dao.IPlanDao;
import com.deccan.dao.PlanDaoImpl;
import com.deccan.dto.PlanFrom;
import com.deccan.exception.BatchException;
import com.deccan.model.Plan;

public class PlanService implements IPlanService{
	 IPlanDao planDao = new PlanDaoImpl();
	
	private String generatePlanId() {
		return "DP"+Math.round(Math.random()*99999);
	}

	@Override
	public List<PlanFrom> displayPlans() throws Exception {
		
		return planDao.displayPlans();
	}

	@Override
	public int addPlan(Plan plan) throws Exception {
		plan.setPlanId(generatePlanId());
		
		return planDao.addPlan(plan);
	}

	@Override
	public Plan update(Plan plan) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void removePlan(String planId) {
		// TODO Auto-generated method stub
		
	}

	
	
	

}
