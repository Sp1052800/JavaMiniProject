package com.deccan.dto;

import java.time.LocalDate;
import java.time.LocalTime;

public class EnrollmentInfo {

	private String enrollmentId;
	private String memberName;
	private String planName;
	private LocalDate startDate;
	private int batchSize;
	private LocalTime batchStartTime;
	private String status;

	public EnrollmentInfo() {
		// TODO Auto-generated constructor stub
	}

	public EnrollmentInfo(String enrollmentId, String memberName, String planName, LocalDate startDate, int batchSize,
			LocalTime batchStartTime, String status) {
		super();
		this.enrollmentId = enrollmentId;
		this.memberName = memberName;
		this.planName = planName;
		this.startDate = startDate;
		this.batchSize = batchSize;
		this.batchStartTime = batchStartTime;
		this.status = status;
	}

	public String getEnrollmentId() {
		return enrollmentId;
	}

	public void setEnrollmentId(String enrollmentId) {
		this.enrollmentId = enrollmentId;
	}

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public LocalTime getBatchStartTime() {
		return batchStartTime;
	}

	public void setBatchStartTime(LocalTime batchStartTime) {
		this.batchStartTime = batchStartTime;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public int getBatchSize() {
		return batchSize;
	}

	public void setBatchSize(int batchSize) {
		this.batchSize = batchSize;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "EnrollmentInfo [enrollmentId=" + enrollmentId + ", memberName=" + memberName + ", planName=" + planName
				+ ", startDate=" + startDate + ", batchSize=" + batchSize + ", batchStartTime=" + batchStartTime
				+ ", status=" + status + "]";
	}

}
