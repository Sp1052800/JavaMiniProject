package com.deccan.model;

public class Sport {
	private String sportsId;
	private String sportName;
	public Sport() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Sport(String sportId, String sportName) {
		super();
		this.sportsId = sportId;
		this.sportName = sportName;
	}
	public String getSportId() {
		return sportsId;
	}
	public void setSportId(String sportId) {
		this.sportsId = sportId;
	}
	public String getSportName() {
		return sportName;
	}
	public void setSportName(String sportName) {
		this.sportName = sportName;
	}
	@Override
	public String toString() {
		return "Sport [sportId=" + sportsId + ", sportName=" + sportName + "]";
	}
	
}
