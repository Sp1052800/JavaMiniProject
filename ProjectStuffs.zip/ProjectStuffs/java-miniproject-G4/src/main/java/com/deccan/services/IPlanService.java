package com.deccan.services;

import java.util.List;

import com.deccan.dto.PlanFrom;
import com.deccan.exception.BatchException;
import com.deccan.model.Plan;

public interface IPlanService {
	public List<PlanFrom> displayPlans() throws BatchException, Exception ;
	public int addPlan(Plan plan) throws Exception;
	public Plan update(Plan plan);
	public void removePlan(String planId);
}
