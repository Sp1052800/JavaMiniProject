package com.deccan.exception;

public class BatchException extends Exception{

	public BatchException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}
	
}
