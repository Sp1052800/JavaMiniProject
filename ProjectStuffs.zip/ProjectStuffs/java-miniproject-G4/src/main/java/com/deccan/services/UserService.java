package com.deccan.services;

import java.util.List;

import com.deccan.dao.IBatchDao;
import com.deccan.dao.IEnrollmentDao;
import com.deccan.dao.IPlanDao;
import com.deccan.dao.ISportDao;
import com.deccan.dao.IUserDao;
import com.deccan.dao.UserDaoImpl;
import com.deccan.exception.UserException;
import com.deccan.model.AllPlansInfo;
import com.deccan.model.User;

public class UserService implements IUserService {

	public UserService() {
		super();
		// TODO Auto-generated constructor stub
	}

	private IUserDao userDao = new UserDaoImpl();
	private IPlanDao planDao;
	private IBatchDao batchDao;
	private IEnrollmentDao enrollmentDao;
	private ISportDao sportDao;

	private String generateUserId() {
		return "DU" + Math.round(Math.random() * 99999);
	}

	@Override
	public User register(User user) throws Exception {
		System.out.println("In userService implementation  " + user);
		user.setUserId(generateUserId());
		//user.setRole("member");
		userDao.register(user);

		return null;
	}

	
	
	@Override
	public User login(String email, String password) throws UserException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User updateUser(User user) throws Exception {
		return userDao.updateUser(user);
	}

	@Override
	public String logout(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<User> displayUsers() throws UserException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<User> displayManagers() throws Exception {
		// TODO Auto-generated method stub
		return userDao.displayManagers();
	}

	@Override
	public void removeManager(String userId) throws Exception {
		userDao.removeManager(userId);

	}

	@Override
	public void userActivity() {
		// TODO Auto-generated method stub

	}

	@Override
	public User getUser(String userId) throws Exception {
		// TODO Auto-generated method stub
		return userDao.getUser(userId);
	}


	@Override
	public User updateManager(User user) throws Exception {
		return userDao.updateManager(user);
		
	}

	@Override
	public List<AllPlansInfo> displayPlans() throws Exception {
		System.out.println("In userservice planlist ");
		return userDao.displayPlanlist();
	}

	@Override
	public User getUserByEmail(String userEmail) throws Exception {
		return userDao.getUserByEmail(userEmail);
	}
	
	@Override
	public User addManager(User user) throws Exception {
		user.setUserId(generateUserId());
		return userDao.addManager(user);
		
	}

}
