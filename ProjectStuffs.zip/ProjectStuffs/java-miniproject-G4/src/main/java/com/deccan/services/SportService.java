package com.deccan.services;

import java.util.List;

import com.deccan.dao.ISportDao;
import com.deccan.dao.SportDaoImpl;
import com.deccan.model.Sport;

public class SportService implements ISportService{
	ISportDao sportDao = new SportDaoImpl();
	
	private String generateSportsId() {
		return "DS"+Math.round(Math.random()*99999);
	}

	@Override
	public List<Sport> displaySports() throws Exception {
		
		return sportDao.displaySports();
	}

	@Override
	public Sport addSport(Sport sport) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Sport updateSport(Sport sport) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void removeSport(String sportId) {
		// TODO Auto-generated method stub
		
	}
	
	
}
